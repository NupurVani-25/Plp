package com.cg.PaymentWalletApplicationUsingJDBC.exception;

public class InvalidInputException {

}
