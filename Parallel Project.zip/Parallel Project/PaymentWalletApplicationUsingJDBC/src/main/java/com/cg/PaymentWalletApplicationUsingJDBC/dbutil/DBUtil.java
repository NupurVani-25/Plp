package com.cg.PaymentWalletApplicationUsingJDBC.dbutil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class DBUtil  {
	public Connection getConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// Setup the connection with the DB
		Connection connect = null;
		try {
			connect = DriverManager
					.getConnection("jdbc:mysql://localhost/nupur?" + "user=nupur&password=nupur");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println(connect);
		// TODO Auto-generated method stub
		return connect;
	}
	
	}


