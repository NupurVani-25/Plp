package com.cg.PaymentWalletApplicationUsingJDBC.service;

public interface IPaymentWalletService {

}
