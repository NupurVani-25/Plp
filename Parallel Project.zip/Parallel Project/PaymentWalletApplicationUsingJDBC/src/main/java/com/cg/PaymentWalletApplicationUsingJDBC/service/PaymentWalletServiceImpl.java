package com.cg.PaymentWalletApplicationUsingJDBC.service;

public class PaymentWalletServiceImpl {

}
