package com.cg.PaymentWalletApplicationUsingJDBC.service;

public class Validation {

}
