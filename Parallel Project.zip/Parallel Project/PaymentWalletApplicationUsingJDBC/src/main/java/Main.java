import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.cg.PaymentWalletApplicationUsingJDBC.dbutil.DBUtil;

public class Main {

	public static void main(String[] args)  {
	

		
	}

}
