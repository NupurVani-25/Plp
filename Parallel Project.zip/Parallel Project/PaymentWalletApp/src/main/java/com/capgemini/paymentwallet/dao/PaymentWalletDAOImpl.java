package com.capgemini.paymentwallet.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.capgemini.paymentwallet.bean.Wallet;

public class PaymentWalletDAOImpl implements IPaymentWalletDAO {

	static HashMap<String, Wallet> map = new HashMap<>();
	static Wallet account;
	static List<String> transaction = new ArrayList<String>();

	int tId = (int) ((Math.random() * 123) + 999);

	public boolean checkMobileNo(String mobileNo) {
		for (String key : map.keySet()) {
			account = map.get(key);
			if (account.getCustomerDetails().getCustomerMobileNo().equals(mobileNo))
				return false;
		}
		return true;
	}

	public boolean checkUserName(String uName) {
		for (String key : map.keySet()) {
			account = map.get(key);
			if (account.getCustomerDetails().getUserName().equals(uName))
				return false;
		}

		return true;
	}

	public boolean checkAadharNo(String aadhar) {
		for (String key : map.keySet()) {
			account = map.get(key);
			if (account.getCustomerDetails().getAadharNo().equals(aadhar))
				return false;
		}
		return true;

	}

	public boolean addWalletDetails(Wallet wallet) {

		for (String key : map.keySet()) {
			if (wallet.getCustomerDetails().getUserName().equals(key)) // UserName already exist
			{
				return false;
			}
		}

		map.put(wallet.getCustomerDetails().getUserName(), wallet); // New Account added to Collection
		return true;
	}

	public boolean loginAccount(String uName, String uPassword) {

		for (String key : map.keySet()) {
			account = map.get(key);
			if (account.getCustomerDetails().getUserName().equals(uName)
					&& account.getCustomerDetails().getUserPassword().equals(uPassword)) {
				return true;
			}
		}
		return false;

	}

	public float showBalance() {

		return account.getCustomerBalance(); // return account balance
	}

	public boolean depositAmount(float amount) {

		account.setCustomerBalance(account.getCustomerBalance() + amount); // Depositing Amount
		String deposit = tId + "  Amount of " + amount + " is deposited:      " + account.getCustomerBalance();
		transaction.add(deposit);
		return true;
	}

	@Override
	public boolean withdrawAmount(float amount) {

		if (account.getCustomerBalance() >= (amount + 1000)) // Minimum Balance Check
		{
			account.setCustomerBalance(account.getCustomerBalance() - amount); // if true then withdraw.

			String with = tId + "  Amount of " + amount + " is withdrawn:     " + account.getCustomerBalance();
			transaction.add(with);
			return true;
		} else {
			System.out.println("Minimum Balance Violation");
		}
		return false;

	}

	@Override
	public boolean fundTransfer(int accNo, float amount) {

		if (account.getCustomerBalance() < (amount + 1000)) {
			System.out.println("Minimum Balance Violation");
			return false;
		}

		for (String key : map.keySet()) {
			Wallet recvAccount = map.get(key);
			if (recvAccount.getCustomerAccountNo() == accNo) {

				recvAccount.setCustomerBalance(recvAccount.getCustomerBalance() + amount);
				account.setCustomerBalance(account.getCustomerBalance() - amount);

				String transfer = tId + "  Amount of " + amount + " is withdrawn from " + account.getCustomerAccountNo()
						+ "and deposited in" + recvAccount.getCustomerAccountNo();

				transaction.add(transfer);
				return true;

			}

		}

		System.out.println("Incorrect Reciever Account Number"); // Fails to match account number

		return false;
	}

	@Override
	public List<String> printTransaction() {

		return transaction;
	}

}
