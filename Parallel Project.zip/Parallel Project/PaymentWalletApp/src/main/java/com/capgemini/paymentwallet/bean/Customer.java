package com.capgemini.paymentwallet.bean;

public class Customer {

	private String aadharNo;
	private String customerName;
	private int age;
	private String gender;
	private String customerMobileNo;
	private String customerEmail;
	private String userName;
	private String userPassword;

	
	public String getAadharNo() {
		return aadharNo;
	}


	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}


	public String getCustomerName() {
		return customerName;
	}


	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public String getCustomerMobileNo() {
		return customerMobileNo;
	}


	public void setCustomerMobileNo(String customerMobileNo) {
		this.customerMobileNo = customerMobileNo;
	}


	public String getCustomerEmail() {
		return customerEmail;
	}


	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getUserPassword() {
		return userPassword;
	}


	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}


	@Override
	public String toString() {
		return "Customer [aadharNo=" + aadharNo + ", customerName=" + customerName + ", age=" + age + ", gender="
				+ gender + ", customerMobileNo=" + customerMobileNo + ", customerEmail=" + customerEmail + ", userName="
				+ userName + ", userPassword=" + userPassword + "]";
	}

}
