package com.cg.spring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.dao.IPaymentWalletDAO;
import com.cg.spring.dto.Customer;
@Service
public class PaymentWalletServiceImpl implements  IPaymentWalletService {
@Autowired
	private IPaymentWalletDAO dao;
	@Override
	public float showBalance() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean depositAmount(float amount) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean withdrawAmount(float amount) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean loginAccount(String uName, String uPassword) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean fundTransfer(String uname, float amount) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String printTransaction() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void addWalletDetails(Customer customer) {
		// TODO Auto-generated method stub
		dao.save(customer);
	}

}
