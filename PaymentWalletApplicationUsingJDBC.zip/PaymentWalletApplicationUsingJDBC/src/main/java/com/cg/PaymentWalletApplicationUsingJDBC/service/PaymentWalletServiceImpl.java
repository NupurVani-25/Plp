package com.cg.PaymentWalletApplicationUsingJDBC.service;


import com.cg.PaymentWalletApplicationUsingJDBC.bean.Wallet;
import com.cg.PaymentWalletApplicationUsingJDBC.dao.PaymentWalletDAOImpl;

public class PaymentWalletServiceImpl implements IPaymentWalletService{

PaymentWalletDAOImpl dao = new PaymentWalletDAOImpl();
	
	
	
	
	
	
	public boolean addWalletDetails(Wallet wallet)
	{
		return dao.addWalletDetails(wallet);
	}

	public float showBalance() {
	
		
		return dao.showBalance();
	}
	

	
	


	public boolean withdrawAmount(float amount) {
		
		return dao.withdrawAmount(amount);
	}

	
	
	
	
	public boolean fundTransfer(int accNo, float amount) {
		
		return dao.fundTransfer(accNo,amount);
	}
	
	

	public boolean loginAccount(String uName, String uPassword) {
		
		return dao.loginAccount(uName, uPassword);
	}
	

	

	public boolean depositAmount(float amount) {
		return dao.depositAmount(amount);
	}

	public void printTransaction() {
	
		 dao.printTransaction();
	}

	

	
	
	
}
