package com.capgemini.paymentapp.exception;

public class InsufficientBalanceExp  extends Exception{

	
	private static final long serialVersionUID = 1L;

}
