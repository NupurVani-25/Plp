package com.cg.spring.SpringDataJPA.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.spring.SpringDataJPA.beans.Product;

@Repository("productrepo")
public interface ProductRepository extends CrudRepository<Product, String>{

}
