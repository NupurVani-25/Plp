package com.cg.spring.SpringDataJPA.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.spring.SpringDataJPA.beans.Product;
import com.cg.spring.SpringDataJPA.service.ProductService;



@RestController
public class ProductController {
	@Autowired
	private ProductService service;
	
	@RequestMapping("/products")
	public List<Product> Products() {
		return service.getAllProducts();
	}

	@RequestMapping("/products/{id}")
	public Optional<Product> getProductById(@PathVariable String id) {
		return service.getProductById(id);

	}

	@RequestMapping(value = "/products", method = RequestMethod.POST)
	public void addProduct(@RequestBody Product p) {
		service.addProduct(p);
	}

	@RequestMapping(value = "/products/{id}", method = RequestMethod.DELETE)
	public void DeleteProduct(@PathVariable String id) {
		service.deleteProduct(id);
	}
	
	@RequestMapping(value = "/products/{id}", method = RequestMethod.PUT)
	public void UpdateProduct(@RequestBody Product p,@PathVariable String id) {
		service.updateProduct(p, id);
	}
}
