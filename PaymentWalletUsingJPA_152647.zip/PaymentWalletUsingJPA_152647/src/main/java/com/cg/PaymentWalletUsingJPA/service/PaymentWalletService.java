package com.cg.PaymentWalletUsingJPA.service;

import java.util.List;

import com.cg.PaymentWalletUsingJPA.beans.Customer;
import com.cg.PaymentWalletUsingJPA.beans.Wallet;
import com.cg.PaymentWalletUsingJPA.dao.PaymentWalletDAOImpl;



public class PaymentWalletService implements IPaymentWalletService {

	PaymentWalletDAOImpl dao = new PaymentWalletDAOImpl();

	
	public boolean addWalletDetails(Customer account)
	{
		return dao.addWalletDetails(account);
	}

	public float showBalance() {
	
		
		return dao.showBalance();
	}
	

	public boolean depositAmount(float amount) {
		
		
		return dao.depositAmount(amount);
	}
	

	public boolean withdrawAmount(float amount) {
		
		return dao.withdrawAmount(amount);
	}

	
	
	
	public boolean fundTransfer(String accNo, float amount) {
		
		return dao.fundTransfer(accNo,amount);
	}
	
	

	public boolean loginAccount(String uName, String uPassword) {
		
		return dao.loginAccount(uName, uPassword);
	}
	

	public String printTransaction() {

		return dao.printTransaction();
	}

	
	
	
	
}

