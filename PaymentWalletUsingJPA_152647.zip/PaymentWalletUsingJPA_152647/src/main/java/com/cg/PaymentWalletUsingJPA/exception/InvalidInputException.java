package com.cg.PaymentWalletUsingJPA.exception;

public class InvalidInputException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
